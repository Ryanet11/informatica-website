<?php 
$x = 3;
if ($x > 2) {
    echo "bigger than 2";
} else {
    echo "equal to or smaller than 2";
}

?>